#!/bin/bash
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P) || exit 1
exec /bin/bash "$HERE/tools/audio_fresh.sh" verify
