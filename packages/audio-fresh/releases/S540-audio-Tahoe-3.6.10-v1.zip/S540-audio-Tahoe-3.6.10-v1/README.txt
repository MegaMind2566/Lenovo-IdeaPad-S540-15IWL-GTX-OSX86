S540 AUDIO — INSTALLAZIONE PULITA TAHOE
VoodooHDA 3.6.10 S540 — pacchetto v1

Per Lenovo IdeaPad S540-15IWL GTX, Intel HDAS / ALC257, macOS Tahoe 26.
Contiene il driver originale firmato, con le correzioni gia collaudate per
microfono e regolazione fine del volume. Nessuna compilazione o modifica
del driver. Il nuovo installer non richiede il vecchio Samsung o i suoi backup.

INSTALLAZIONE

1. Estrai l'intera cartella S540-audio-Tahoe-3.6.10-v1 in Download.
2. Nel Terminale esegui:

bash "$HOME/Downloads/S540-audio-Tahoe-3.6.10-v1/INSTALLA-AUDIO.command"

3. Inserisci la password amministratore quando richiesta.
4. Se macOS richiede di autorizzare il driver, apri Impostazioni di Sistema >
   Privacy e sicurezza, approva e riesegui lo stesso comando.
   Segui un eventuale riavvio richiesto espressamente da macOS.
5. Quando l'installer indica di riavviare, riavvia normalmente. Poi esegui:

bash "$HOME/Downloads/S540-audio-Tahoe-3.6.10-v1/VERIFICA-AUDIO.command"

6. Nelle impostazioni Suono seleziona l'uscita desiderata e prova altoparlanti,
   volume basso, cuffie e microfono. La verifica conferma il caricamento e le
   due correzioni del driver; l'ascolto e la prova del microfono restano necessari.

Se l'installer si ferma, conserva il messaggio completo. Una richiesta in attesa
di autorizzazione non significa che l'audio sia gia funzionante. Puoi rieseguire
INSTALLA-AUDIO senza ricopiare un driver identico gia gestito dal pacchetto.

COSA VIENE INSTALLATO

/Library/Extensions/VoodooHDA.kext

Stato e log sono conservati nel nuovo macOS, nella cartella:
/Library/Application Support/S540-audio-fresh-3.6.10

Il programma verifica prima tutti e tre i file originali, la firma, il sistema,
il volume Data attuale e i prerequisiti della configurazione S540. Non sovrascrive
un VoodooHDA gia presente senza il proprio registro. Richiede il SIP gia usato
per questo driver (03000000) e voodoo-layout-id=11 attivo all'avvio; legge questi
valori ma non modifica EFI, SIP o NVRAM.

RIMOZIONE

bash "$HOME/Downloads/S540-audio-Tahoe-3.6.10-v1/RIMUOVI-AUDIO.command"

Rimuove soltanto il driver identico installato da questo pacchetto, conservandone
una copia nel registro. Dopo la ricostruzione riuscita riavvia e riesegui
VERIFICA-AUDIO. Il controllo confermera che il driver non e piu caricato.
Se macOS lascia la ricostruzione in attesa, segui il messaggio e riesegui RIMUOVI.

PROVENIENZA

Driver estratto senza modifiche da S540-volume-fine-v1.zip.
SHA-256 dell'archivio originale:
b220a01aff5ecd8f0617088c197e89e7fde93d75d5049b4c59a6bf028b370e8b

Metadati originali: ORIGINAL-BUILD.json
Manifest originale: assets/SHA256SUMS
Licenze originali: licenses/audio-tahoe/

Il precedente INSTALL-VOLUME.command era un aggiornamento che richiedeva lo
stato S540-microfono del vecchio sistema. Non e incluso in questa versione.
I percorsi nel manifest sono relativi all'interno di VoodooHDA.kext: l'installer
nuovo calcola sempre i percorsi corretti, qualunque sia la cartella del Terminale.

Il pacchetto e i percorsi dei file sono controllati localmente. I comandi nativi
macOS e l'effettivo caricamento vengono verificati sul Mac durante l'installazione
e dopo il riavvio; questo nuovo installer non e stato eseguito su un Mac di prova.
