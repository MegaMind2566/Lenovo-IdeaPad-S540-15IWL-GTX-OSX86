#!/bin/bash
# Bash 3.2 / Intel macOS Tahoe. Original, unchanged S540 3.6.10 payload.
set -euo pipefail
umask 077
export LC_ALL=C
export PATH=/usr/bin:/bin:/usr/sbin:/sbin

HERE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
PAYLOAD="$HERE/assets/VoodooHDA.kext"
MANIFEST="$HERE/assets/SHA256SUMS"
MANIFEST_HASH=bee4f25f9b87dd79f5f5fc9ee0d81521a65c3f84d3493410ee2a9e121bbc536f
DEST=/Library/Extensions/VoodooHDA.kext
RECORD='/Library/Application Support/S540-audio-fresh-3.6.10'
STATE="$RECORD/state.plist"
LOCK=/private/var/run/S540-audio-fresh.lock
TEMP=''
LOCKED=0
MODE=${1:-install}

fail() { printf '\nAUDIO: %s\n' "$*" >&2; exit 1; }
cleanup() {
    if [ -n "$TEMP" ]; then
        case "$TEMP" in /private/tmp/S540AudioFresh.*) /bin/rm -rf "$TEMP";; esac
    fi
    if [ "$LOCKED" -eq 1 ]; then /bin/rmdir "$LOCK" 2>/dev/null || true; fi
}
trap cleanup EXIT
hash() {
    if [ -x /usr/bin/shasum ]; then /usr/bin/shasum -a 256 "$1" | /usr/bin/awk '{print $1}';
    else /usr/bin/openssl dgst -sha256 "$1" | /usr/bin/awk '{print $NF}'; fi
}
readkey() { /usr/bin/plutil -extract "$2" raw -o - "$1"; }
ordinary() { [ -f "$1" ] && [ ! -L "$1" ]; }
shape() {
    local bundle=$1 file count
    [ -d "$bundle" ] && [ ! -L "$bundle" ] || fail "Bundle assente o non valido: $bundle"
    [ -z "$(/usr/bin/find "$bundle" ! -type d ! -type f -print)" ] || fail 'Il bundle contiene collegamenti o file speciali.'
    count=$(/usr/bin/find "$bundle" -type f -print | /usr/bin/wc -l | /usr/bin/tr -d '[:space:]')
    [ "$count" = 3 ] || fail 'Il driver deve contenere esattamente i tre file originali.'
    for file in Contents/Info.plist Contents/MacOS/VoodooHDA Contents/_CodeSignature/CodeResources; do
        ordinary "$bundle/$file" || fail "File del driver mancante: $file"
    done
}
check_manifest() {
    ordinary "$MANIFEST" || fail 'Manifest del pacchetto mancante.'
    [ "$(hash "$MANIFEST")" = "$MANIFEST_HASH" ] || fail 'Il manifest del pacchetto e stato alterato.'
}
matches() {
    local bundle=$1 expected relative
    shape "$bundle"
    check_manifest
    while IFS=' ' read -r expected relative; do
        relative=${relative# }
        [ "$(hash "$bundle/$relative")" = "$expected" ] || return 1
    done < "$MANIFEST"
}
check_payload() {
    matches "$PAYLOAD" || fail 'Il contenuto del driver non corrisponde al pacchetto originale.'
    printf 'Pacchetto completo: tre file del driver verificati SHA-256.\n'
}
signature() { /usr/bin/codesign --verify --strict "$1" || fail 'Firma del driver non valida.'; }
owned_directory() {
    local dir=$1 mode
    [ -d "$dir" ] && [ ! -L "$dir" ] || fail "Directory non valida: $dir"
    [ "$(/usr/bin/stat -f %u "$dir")" = 0 ] || fail "Directory non appartenente a root: $dir"
    mode=$(/usr/bin/stat -f %Lp "$dir")
    [ $((8#$mode & 0022)) -eq 0 ] || fail "Directory scrivibile da altri utenti: $dir"
}
phase() {
    local next
    next=$(/usr/bin/mktemp "$RECORD/.state.XXXXXX")
    /bin/cp "$STATE" "$next"
    /usr/bin/plutil -replace Phase -string "$1" "$next"
    if [ -n "${2:-}" ]; then /usr/bin/plutil -replace "$2" -string "$BOOT_UUID" "$next"; fi
    /bin/chmod 600 "$next"
    /bin/mv -f "$next" "$STATE"
    PHASE=$1
}
runtime() {
    [ "$(/usr/bin/uname -s)" = Darwin ] || fail 'Questo comando richiede macOS.'
    [ "$(/usr/bin/uname -m)" = x86_64 ] || fail 'Questo pacchetto richiede un sistema Intel.'
    case "$(/usr/bin/sw_vers -productVersion)" in 26.*) ;; *) fail 'Pacchetto dedicato a macOS Tahoe 26.';; esac
    case "$(/usr/bin/uname -r)" in 25.*) ;; *) fail 'Kernel non corrispondente a Tahoe.';; esac
    TEMP=$(/usr/bin/mktemp -d /private/tmp/S540AudioFresh.XXXXXX)
    /usr/sbin/diskutil info -plist /System/Volumes/Data > "$TEMP/data.plist"
    [ "$(readkey "$TEMP/data.plist" FilesystemType)" = apfs ] || fail 'Il volume Data non e APFS.'
    [ "$(readkey "$TEMP/data.plist" MountPoint)" = /System/Volumes/Data ] || fail 'Volume Data non identificato.'
    DATA_UUID=$(readkey "$TEMP/data.plist" VolumeUUID)
    case "$DATA_UUID" in ''|*[!a-fA-F0-9-]*) fail 'UUID Data non valido.';; esac
    [ "${#DATA_UUID}" -eq 36 ] || fail 'UUID Data incompleto.'
    BOOT_UUID=$(/usr/sbin/sysctl -n kern.bootsessionuuid)
}
audio_prerequisites() {
    /usr/sbin/nvram -x csr-active-config > "$TEMP/sip.plist"
    [ "$(readkey "$TEMP/sip.plist" csr-active-config)" = AwAAAA== ] || fail 'SIP attivo diverso dalla configurazione audio gia collaudata (03000000). Nessuna modifica automatica alla EFI.'
    /usr/sbin/sysctl -n kern.bootargs > "$TEMP/bootargs.txt"
    if /usr/bin/grep -Eq '(^|[[:space:]])(-x|-igfxvesa)([[:space:]]|$)' "$TEMP/bootargs.txt"; then
        fail 'Avvia macOS normalmente, senza modalita sicura o grafica VESA, prima di installare.'
    fi
    /usr/bin/grep -Eq '(^|[[:space:]])voodoo-layout-id=11([[:space:]]|$)' "$TEMP/bootargs.txt" || fail 'Manca voodoo-layout-id=11 nella configurazione di avvio. Nessuna modifica automatica alla EFI.'
    /usr/bin/kmutil showloaded > "$TEMP/loaded.txt" 2> "$TEMP/loaded.err" || { /bin/cat "$TEMP/loaded.err" >&2; fail 'Impossibile leggere i driver caricati.'; }
    if /usr/bin/grep -Eiq 'as\.vit9696\.AppleALC|com\.apple\.driver\.AppleHDA([[:space:](]|$)' "$TEMP/loaded.txt"; then
        fail 'AppleALC/AppleHDA concorrente caricato; installazione fermata.'
    fi
    [ ! -e /Library/Extensions/AppleHDA.kext ] && [ ! -L /Library/Extensions/AppleHDA.kext ] || fail 'AppleHDA presente in Library/Extensions; installazione fermata.'
    /usr/sbin/ioreg -r -n HDAS -l -w 0 > "$TEMP/controller.txt"
    /usr/bin/grep -Eq 'HDAS@1[Ff],3' "$TEMP/controller.txt" && /usr/bin/grep -Eq '"vendor-id" = <86800000>' "$TEMP/controller.txt" || fail 'Controller Intel HDAS dell S540 non rilevato.'
}
load_state() {
    owned_directory "$RECORD"
    ordinary "$STATE" || fail 'Registro di questa installazione assente o non valido.'
    [ "$(/usr/bin/stat -f %u "$STATE")" = 0 ] || fail 'Registro non appartenente a root.'
    [ "$(readkey "$STATE" Format)" = 1 ] || fail 'Formato del registro non riconosciuto.'
    [ "$(readkey "$STATE" DataVolumeUUID)" = "$DATA_UUID" ] || fail 'Il registro appartiene a un altro macOS.'
    [ "$(readkey "$STATE" PayloadManifestHash)" = "$MANIFEST_HASH" ] || fail 'Registro di un altro driver.'
    [ "$(readkey "$STATE" DriverWasAbsent)" = true ] || fail 'Stato iniziale non riconosciuto.'
    PHASE=$(readkey "$STATE" Phase)
    case "$PHASE" in prepared|installed|loadpending|approvalpending|rebootrequired|verified|removing|removepending|removerebootrequired|removed) ;; *) fail 'Fase non riconosciuta.';; esac
}
new_state() {
    local draft entry
    [ ! -e "$DEST" ] && [ ! -L "$DEST" ] || fail 'VoodooHDA e gia presente senza il registro di questo pacchetto: non viene sovrascritto.'
    if [ -e "$RECORD" ] || [ -L "$RECORD" ]; then
        owned_directory "$RECORD"
        for entry in "$RECORD"/* "$RECORD"/.[!.]* "$RECORD"/..?*; do
            [ -e "$entry" ] || [ -L "$entry" ] || continue
            case "$entry" in "$RECORD"/.state.*) ordinary "$entry" || fail 'Bozza del registro non valida.';;
                *) fail 'Directory del registro gia presente senza uno stato valido.';; esac
        done
    else /bin/mkdir "$RECORD"; fi
    /bin/chmod 700 "$RECORD"
    draft=$(/usr/bin/mktemp "$RECORD/.state.XXXXXX")
    printf '%s\n' '<?xml version="1.0" encoding="UTF-8"?>' '<plist version="1.0"><dict/></plist>' > "$draft"
    /usr/bin/plutil -insert Format -integer 1 "$draft"
    /usr/bin/plutil -insert DataVolumeUUID -string "$DATA_UUID" "$draft"
    /usr/bin/plutil -insert PayloadManifestHash -string "$MANIFEST_HASH" "$draft"
    /usr/bin/plutil -insert DriverWasAbsent -bool true "$draft"
    /usr/bin/plutil -insert InstallBootSession -string "$BOOT_UUID" "$draft"
    /usr/bin/plutil -insert RemovalBootSession -string '' "$draft"
    /usr/bin/plutil -insert Phase -string prepared "$draft"
    /bin/chmod 600 "$draft"
    /bin/mv "$draft" "$STATE"
    PHASE=prepared
}
kernel_symbols() {
    if ! /usr/bin/kmutil libraries --bundle-path "$PAYLOAD" --xml > "$TEMP/symbols.xml" 2> "$TEMP/symbols.err"; then
        /bin/cat "$TEMP/symbols.err" >&2
        /usr/bin/tail -n 40 "$TEMP/symbols.xml" >&2
        fail 'Dipendenze del driver non risolte sul kernel attuale. Nessun driver installato.'
    fi
}
request_load() {
    local status rebuild_status
    phase loadpending InstallBootSession
    set +e
    /usr/bin/kmutil load -p "$DEST" > "$RECORD/kmutil-load.log" 2>&1
    status=$?
    set -e
    /bin/cat "$RECORD/kmutil-load.log"
    case "$status" in
        0) phase rebootrequired InstallBootSession;;
        27)
            phase approvalpending
            printf '\nAPPROVAZIONE NECESSARIA: Impostazioni di Sistema > Privacy e sicurezza.\nApprova VoodooHDA, poi riesegui INSTALLA-AUDIO.command.\n'
            return 0;;
        28)
            # A reboot is often requested by load. Ask rebuild to establish its outcome.
            set +e
            /usr/bin/kmutil rebuild > "$RECORD/kmutil-rebuild.log" 2>&1
            rebuild_status=$?
            set -e
            /bin/cat "$RECORD/kmutil-rebuild.log"
            case "$rebuild_status" in
                0) phase rebootrequired InstallBootSession;;
                27|28)
                    phase approvalpending
                    printf '\nCOLLEZIONE ANCORA IN ATTESA: segui il messaggio macOS sopra.\nDopo eventuale approvazione riesegui INSTALLA-AUDIO.command.\nSe macOS chiede espressamente un riavvio, segui tale richiesta; non e ancora una verifica audio riuscita.\n'
                    return 0;;
                *) fail 'Ricostruzione non completata. Conserva il messaggio e il log; il driver non viene ricopiato.';;
            esac;;
        *) fail 'Richiesta di caricamento non completata. Conserva il messaggio; nessun riavvio automatico.';;
    esac
    printf '\nFILE INSTALLATI E RICHIESTA COMPLETATA. Riavvia normalmente.\nDopo il riavvio esegui VERIFICA-AUDIO.command e prova l audio.\n'
}
install() {
    audio_prerequisites
    signature "$PAYLOAD"
    kernel_symbols
    if [ ! -e "$STATE" ] && /usr/bin/grep -Fq org.voodoo.driver.VoodooHDA "$TEMP/loaded.txt"; then
        fail 'VoodooHDA e gia caricato fuori da questa installazione: nessuna copia effettuata.'
    fi
    if ordinary "$STATE"; then load_state; else new_state; fi
    case "$PHASE" in removing|removepending|removerebootrequired|removed) fail 'Questa installazione e stata rimossa o e in rimozione.';; esac
    if [ -e "$DEST" ] || [ -L "$DEST" ]; then
        matches "$DEST" || fail 'Il driver presente e diverso da quello gestito: non viene sostituito.'
        signature "$DEST"
    else
        [ "$PHASE" = prepared ] || fail 'Il driver installato in precedenza e scomparso: nessuna ricopia automatica.'
        local stage="$RECORD/staging/VoodooHDA.kext"
        if [ -e "$RECORD/staging" ] || [ -L "$RECORD/staging" ]; then
            owned_directory "$RECORD/staging"
            if [ -e "$stage" ] || [ -L "$stage" ]; then
                if ! (matches "$stage"); then
                    /bin/mv "$stage" "$RECORD/interrupted-stage.$(/usr/bin/uuidgen).kext"
                    printf 'Copia temporanea interrotta conservata; preparo nuovamente il driver originale.\n'
                fi
            fi
        else /bin/mkdir "$RECORD/staging"; fi
        if [ ! -e "$stage" ]; then /usr/bin/ditto --norsrc --noextattr --noacl --noqtn "$PAYLOAD" "$stage"; fi
        /usr/sbin/chown -R root:wheel "$stage"
        /usr/bin/find "$stage" -type d -exec /bin/chmod 755 {} +
        /usr/bin/find "$stage" -type f -exec /bin/chmod 644 {} +
        /bin/chmod 755 "$stage/Contents/MacOS/VoodooHDA"
        matches "$stage" || fail 'Lo staging non coincide con il driver originale.'
        signature "$stage"
        [ ! -e "$DEST" ] && [ ! -L "$DEST" ] || fail 'Destinazione comparsa durante la preparazione.'
        /bin/sync
        /bin/mv "$stage" "$DEST"
        matches "$DEST" || fail 'Il driver copiato non corrisponde al pacchetto.'
        phase installed
    fi
    if [ "$PHASE" = verified ]; then printf 'Driver gia verificato. Nessuna ricopia necessaria.\n'; return 0; fi
    if [ "$PHASE" = rebootrequired ]; then
        printf 'Driver gia installato. Riavvia, poi esegui VERIFICA-AUDIO.command.\n'; return 0
    fi
    request_load
}
verify() {
    load_state
    if [ "$PHASE" = removerebootrequired ] || [ "$PHASE" = removed ]; then
        [ "$(readkey "$STATE" RemovalBootSession)" != "$BOOT_UUID" ] || fail 'Riavvia prima di verificare la rimozione.'
        /usr/bin/kmutil showloaded > "$TEMP/loaded.txt" 2> "$TEMP/loaded.err"
        if /usr/bin/grep -Fq org.voodoo.driver.VoodooHDA "$TEMP/loaded.txt"; then fail 'Il vecchio driver e ancora caricato: riavvio necessario.'; fi
        [ ! -e "$DEST" ] && [ ! -L "$DEST" ] || fail 'Un driver e ancora presente nella destinazione.'
        phase removed
        printf 'RIMOZIONE VERIFICATA: VoodooHDA non e installato o caricato.\n'; return 0
    fi
    case "$PHASE" in loadpending|approvalpending|rebootrequired|verified) ;; *) fail 'Installazione non completata. Riesegui INSTALLA-AUDIO.command.';; esac
    [ "$(readkey "$STATE" InstallBootSession)" != "$BOOT_UUID" ] || fail 'Riavvia prima di verificare il driver.'
    matches "$DEST" || fail 'Driver installato assente o diverso.'
    signature "$DEST"
    audio_prerequisites
    /usr/bin/grep -Eq 'org\.voodoo\.driver\.VoodooHDA[[:space:]]+\(3\.6\.10\)' "$TEMP/loaded.txt" || fail 'VoodooHDA 3.6.10 non risulta caricato. Se richiesto, completa approvazione e riavvio.'
    /usr/sbin/ioreg -r -c VoodooHDADevice -l -w 0 > "$TEMP/audio-ioreg.txt"
    /usr/bin/grep -Eq '"S540InputGainFixActive" = (Yes|true)' "$TEMP/audio-ioreg.txt" || fail 'Correzione microfono non attiva sul controller rilevato.'
    /usr/bin/grep -Eq '"S540OutputRangeFixActive" = (Yes|true)' "$TEMP/audio-ioreg.txt" || fail 'Correzione volume non attiva sul controller rilevato.'
    phase verified
    printf '\nDRIVER VERIFICATO: 3.6.10, correzioni microfono e volume attive.\nProva altoparlanti, volume e microfono nelle impostazioni Suono.\n'
}
remove() {
    local status
    load_state
    if [ "$PHASE" = removed ]; then printf 'Driver gia rimosso.\n'; return 0; fi
    if [ -e "$DEST" ] || [ -L "$DEST" ]; then
        matches "$DEST" || fail 'Il driver e stato modificato: non viene rimosso.'
        [ ! -e "$RECORD/removed.kext" ] && [ ! -L "$RECORD/removed.kext" ] || fail 'Copia di rimozione gia presente.'
        phase removing
        /bin/mv "$DEST" "$RECORD/removed.kext"
    else
        case "$PHASE" in removing|removepending|removerebootrequired) matches "$RECORD/removed.kext" || fail 'Copia del driver rimosso non valida.';; *) fail 'Driver assente fuori da una rimozione registrata.';; esac
    fi
    phase removepending RemovalBootSession
    set +e
    /usr/bin/kmutil rebuild > "$RECORD/kmutil-remove.log" 2>&1
    status=$?
    set -e
    /bin/cat "$RECORD/kmutil-remove.log"
    case "$status" in
        0) phase removerebootrequired RemovalBootSession; printf '\nRimozione preparata. Riavvia, poi esegui VERIFICA-AUDIO.command.\n';;
        27|28) printf '\nRimozione in attesa: segui la richiesta macOS e riesegui RIMUOVI-AUDIO.command.\n';;
        *) fail 'Ricostruzione per rimozione non completata; il bundle e conservato nel registro.';;
    esac
}

case "$MODE" in install|verify|remove|check-package) ;; *) fail 'Modalita non riconosciuta.';; esac
check_payload
if [ "$MODE" = check-package ]; then exit 0; fi
[ "$(/usr/bin/uname -s)" = Darwin ] || fail 'Questo installer richiede macOS.'
if [ "$(/usr/bin/id -u)" -ne 0 ]; then exec /usr/bin/sudo /bin/bash "$0" "$MODE"; fi
/bin/mkdir "$LOCK" 2>/dev/null || fail 'Un altra operazione audio e in corso. Se e stata interrotta, riavvia e riprova.'
LOCKED=1
runtime
case "$MODE" in install) install;; verify) verify;; remove) remove;; esac
